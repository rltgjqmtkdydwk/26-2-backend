package net.skhu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class B202214048Application {

	public static void main(String[] args) {
		SpringApplication.run(B202214048Application.class, args);
	}

}
