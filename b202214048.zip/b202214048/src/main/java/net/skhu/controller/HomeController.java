package net.skhu.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import net.skhu.dto.Book;

@Controller
public class HomeController {

    private static final Logger log = LoggerFactory.getLogger(HomeController.class);

    @GetMapping("exam1")
    public String exam1(Model model) {
        model.addAttribute("studentId", "202214048");
        model.addAttribute("name", "김은총");
        return "exam1";
    }

    @GetMapping("exam2")
    public String exam2(Model model) {
        model.addAttribute("book", new Book());
        return "exam2";
    }

    @PostMapping("exam2")
    public String exam2(Book book, Model model) {
        log.debug(book.toString());
        return "exam2";
    }
}