package net.skhu.dto;

import lombok.Data;

@Data
public class Book {
    String title;      // 제목
    String author;     // 저자
    int price;         // 가격
    int categoryId;    // 카테고리
}