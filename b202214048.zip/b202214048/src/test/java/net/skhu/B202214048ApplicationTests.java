package net.skhu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class B202214048ApplicationTests {

	@Test
	void contextLoads() {
	}

}
